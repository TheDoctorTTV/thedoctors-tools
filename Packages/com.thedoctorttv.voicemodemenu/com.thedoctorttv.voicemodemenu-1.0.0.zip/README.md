# Voice Mode Menu

VPM package for the VoiceModeMenu UdonSharp behaviour.

## Install
Add the repository listing to VCC and install `com.thedoctorttv.voicemodemenu`.
